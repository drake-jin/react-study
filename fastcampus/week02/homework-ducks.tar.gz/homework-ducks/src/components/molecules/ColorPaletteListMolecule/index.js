export { default } from './ColorPaletteListMolecule'
