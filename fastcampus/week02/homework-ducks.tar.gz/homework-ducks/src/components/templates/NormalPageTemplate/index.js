export { default } from './NormalPageTemplate'
