export { default } from './ColorPaletteItemAtom'
