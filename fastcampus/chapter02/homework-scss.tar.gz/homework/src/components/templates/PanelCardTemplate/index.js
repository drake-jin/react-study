export { default } from './PanelCardTemplate'
